import './UserStyle.css';
import {useEffect, useState} from "react";



function UserHomePage(){

    return (
        <div className="App">
            <h1> Welcome to your user profile page.
            </h1>
            <h4> To make any modifications, click the edit button above.</h4>

        </div>
    )
}
export default UserHomePage;
