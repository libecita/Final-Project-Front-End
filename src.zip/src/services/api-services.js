export const getUserData = async (API_URL, userId) => {
    const response = await fetch (`${API_URL}/users/${userId}`, {
        method: 'GET', //  THIS IS WHERE YOU SPECIFY THE POST METHOD -- GET request to retrieve user data {

     });
    if (!response.ok) {
        throw new Error(`Failed to fetch user data: ${response.statusText}`);
    }
    const parsed_data = await response.json();
    return parsed_data;
};


    // POST TO ADD NEW USERS
export const postData = async (API_URL, newData) => {
    const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json', //set the content type to JSON
        },
        body: JSON.stringify(newData) // SEND NEW USER DATA

    });
    return response;
};


    // PUT METHOD TO UPDATE DATA
export const putData = async (API_URL,userId, updateData) => {
    const response = await fetch(`${API_URL}/users/${userId}`, {
        method: 'PUT', // SPECIFY THE PUT METHOD
        headers: {
            'Content-Type': 'application/json', //set the content type to JSON
        },
        body: JSON.stringify(updateData)


    });
    if (!response.ok) {
        throw new Error(`Failed to update user: ${response.statusText}`);
    }
    return response;
};

//to delete a user
export const deleteUser = async (API_URL, userId) => {
    try {
        const url = '${API_URL}/${id}';
        console.log(url);

        const response = await fetch(`${API_URL}/users/${userId}`,{
            method: 'DELETE', // SPECIFY THE  METHOD to remove user data
            headers: {
                'Content-Type': 'application/json', //set the content type to JSON
            },
        });

        if (!response.ok) {
            throw new Error(`Failed to delete user: ${response.status} ${response.statusText}`);

        }
        // if the response contains JSON data, parse it
        //Const data = await response.json().catch (() => null); // use catch () in case theres no JSON response
        return response;
    }
    catch (error){
        console.error("Error in deleting user:", error);
        throw error; // optionally re-throw the error for further handling
    }
};