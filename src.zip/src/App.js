// import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';


import UserPage from './user_page/UserPage';
import  React, { Route, Router, Routes} from "react-router-dom";
import UserList from "./user_page/UserList";
import UserHomePage from "./user_page/UserHomePage";
import UserForm from "./user_page/UserForm";

function App() {
  return (
    <div className="App">
      <header className='LikeAHolic'>
        <Router>
          {/* <MyNavBar/>*/}
          <Routes>
            {/*<Route exact path="/" element ={<UserPage/>}></Route>*/}
              <Route exact path="/" element ={<UserHomePage/>}/>
              <Route path="/Users" element = {<UserList/>}/>
          {/*    <Route path="/ Profile" element = {<UserPage/>}/>*/}
          {/*    <Route path="/New User" element = {<UserForm/>}/>*/}
          </Routes>
        </Router>
      </header>
    </div>
  );
}

export default App;
