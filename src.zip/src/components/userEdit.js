import React, { useState } from 'react';


function userEdit() {
    const UserProfile = () => {
        const [isEditing, setIsEditing] = useState(false);

        const handleEditClick = () => {
            setIsEditing(!isEditing);  // Toggle the editing state
        };

        return (
            <div className="profile-container">
                <h1>User Profile</h1>
                <div className="profile-info1">
                    <p><strong>Name:</strong> John Doe</p>
                    <p><strong>Email:</strong> johndoe@example.com</p>
                    <p><strong>Date of Birth:</strong> 12/12/1998</p>
                    <p><strong> Relationship Status:</strong> Single</p>

                </div>

                {/* "Edit" button */}
                <button className="edit-button" onClick={handleEditClick}>
                    Edit
                </button>

                {isEditing && (
                    <div className="edit-form">
                        <input type="text" placeholder="Edit Name"/>
                        <input type="email" placeholder="Edit Email"/>
                        <button>Save</button>
                    </div>
                )}
            </div>
        );
    }
};
export default userEdit;
