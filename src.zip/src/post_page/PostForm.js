import {useEffect, useState} from "react";

export default function PostForm(props){
    const post = props.post
    const onSave = props.onSave
    const [formData,setFormData] = useState({
        postIdentifier:'',
        lastName:'',
        firstName:'',
        emailAddress:'',
        postname:'',
        relationshipStatus:'',
        dateOfBirth:'',
        password:''

    });

    const handleChange = (e)=>{
        const {name,value} =e.target;
        setFormData((prev)=>({...prev,[name]:value}));
    };

    const handleSubmit = (e) =>{
        e.preventDefault();
        onSave(formData, post ? post.postIdentifier : null); //or postIdentifier?
    }
    useEffect(()=>{
        if(post){
            setFormData({
                postIdentifier: post.postIdentifier,
                datePosted: post.datePosted,
                description: post.description,
                title: post.title,
                picture: post.picture,
                username: post.username
            });
        }
    },[post]);
    return(
        <div className="form-container">
            <h2>{post ? 'Edit post' : 'Add New post'}</h2>
            <form s ={handleSubmit}>
                <div className="mb-3">
                    <label>Post ID: </label>
                    <input type="text" name="id" value={post ? post.postIdentifier : 'New ID'} readOnly/>
                </div>
                <div className="mb-3">
                    <label>Date posted: </label>
                    <input type="text" name="dateposted" value={formData.datePosted} c={handleChange} required/>
                </div>
                <div className="mb-3">
                    <label>Description: </label>
                    <input type="text" name="description" value={formData.description} c={handleChange} required/>
                </div>
                <div className="mb-3">
                    <label>Title: </label>
                    <input type="text" name="title" value={formData.title} c={handleChange} required/>
                </div>
                <div className="mb-3">
                    <label>Picture: </label>
                    <input type="text" name="picture" value={formData.picture} c={handleChange} required/>
                </div>
                <div className="mb-3">
                    <label>Username: </label>
                    <input type="text" name="username" value={formData.username} c={handleChange} required/>
                </div>
            </form>
        </div>
    );
}